<?php
include 'connect.php';
$name=$_POST['name'];
$password=$_POST['pass'];
$email=$_POST['email'];
$phone=$_POST['pno'];

$sql_users = "INSERT INTO register(name,password,email,mobile) VALUES ('$name','$password','$email','$phone')";
if (mysqli_query($connect,$sql_users))
{
echo "<script language='javascript'>";
echo "alert('Values inserted successful!! Inserted into the database')";
echo "</script>";
header('Location:Login.html');
}
else
{
echo "<script language='javascript'>";
echo "alert('Registration unsuccessfull, Please try again!')";
echo "</script>";
header('Location:sign.html');
}
?>