<html>
<style>
/*.container { 
  background: url(lCoP1Za.jpg) no-repeat center fixed; 
  background-size: cover;
  

}
*/
#div2{
			border : 1px solid black;
			margin :100px 600px 100px 550px;
			border-radius : 3px;
			padding:20px;width:650px;
			align:center;

}
input[type=submit]{
    			width: 25%;
    			padding: 14px 20px;
    			margin: 8px 10px;
    			cursor: pointer;
    			color: black;
			border-radius : 5px;
			align:center;
}
#img1{
float:left;
}

h1{
text-align:center;
font-style:oblique;
color:#782525;
font-family:"Constantine";
font-size: 50px;
font-variant: small-caps;
}

#ul1 {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
    clear:both;  
}

#li1 {
    float: left;
}

a{
font-family: Constantine;
}

#li1 a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 60px;
    text-decoration: none;
    font-family: "Constantine";
    font-variant: small-caps; 
    font-size: 20px;
}

#li1 a:hover:not(.active) {
    background-color: #DAA520;
}

.active {
    background-color: #DAA520;
}

input[type=text] {
       box-sizing: border-box;
       border: 2px solid #ccc;
       font-size: 16px;
       background-color: white;
 }

input[placeholder="Search.."] {
padding: 5px;
}

h3{
text-align: center;
color:#782525;
font-variant: small-caps;
font-size:25px;

}

#img3{
float: right;
clear:both;
}

#pre1{
font-family:"Constantine";
font-size:20px;

}
#p2{
font-family:"Constantine";
font-size:20px;
text-align: right;
}


#img4{
float:left;
clear:both;
}


br{
clear: both;
}

#li2 a{
font-family:"Constantine";
font-size:20px;
color:black;
}

#pre2{
list-style-type:none; 
font-family:"Constantine";
clear:both;
}

footer{
clear:both;
background-color:#DAA520;
}
</style>

<body>

<img id="img1" src="globetrotlogo.png" alt="Logo" width=300 height=150>
<h1>GlobeTrot Tours
</h1>
<ul id="ul1">
  <li id="li1"><a  href="GTB.html">Home</a></li>
  <li id="li1"><a href="dest123.html">Destinations</a></li>
<li id="li1"><a class="active" href="contact2.php">Contact Us</a></li>
<li id="li1"><a href="logout.html">Log Out</a></li>	
</ul>
<div class="container">
<br>
<div id="div2">
<h1>
  <center>
  CONTACT US</center>
</h1>


<h3> You can contact us, for your questions/feedback through the following: <br>
<br>
Cell: +91 9876543210 or +91 9824527487 <br>	Email us- globtrottours@gmail.com
<br><br>
For the payment of your selected package of the tour, you can courier it to any one of our head offices:<br>
<li>A-501, Paradise Building, sector-32<br> New Panvel, Navi Mumbai, Pincode-410206, India </li><br>
<li>306, Sai Saaj, plot-91, Sector-23 <br> New Delhi, Pincode-234013, India</li>
<br><br> Follow us on facebook- https://www.facebook.com/globetrots/

</div>
<footer>
<h3 id="h31">POPULAR CHOICES</h3>

<ul id="pre2">
<pre>
<li id="li2">                                                              <a href="#">Kerala</a>                         <a href="#">Kashmir</a>                    <a href="#">Leh/Ladakh</a></li><br>
</pre>
</ul>
</footer>

</div>

</body>
</html>



