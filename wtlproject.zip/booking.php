<?php
include 'connect.php';

$name=$_POST['name'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$dest=$_POST['dest'];
$ticket=$_POST['ticket'];
$age=$_POST['age'];
$package=$_POST['package'];
$date=$_POST['date'];

$sql_users = "INSERT INTO booking(name,mobile,email,destination,tickets,age,package,Date) VALUES ('$name','$mobile','$email','$dest','$ticket','$age','$package','$date')";
if (mysqli_query($connect,$sql_users))
{
echo "<script language='javascript'>";
echo "alert('Values inserted successful!! Inserted into the database')";
echo "</script>";
header('Location:dest1234.html');
}
else
{
echo "<script language='javascript'>";
echo "alert('Registration unsuccessfull, Please try again!')";
echo "</script>";
header('Location:Book.html');
}
?>